﻿#define WIN32_LEAN_AND_MEAN
#include "spotify.h"
#include "cpp-httplib/httplib.h"

using namespace nlohmann;

std::string curl_post(std::string url, std::string post_fields) {
    std::string response = "";
    CURL* curl = curl_easy_init();
    if (!curl) return "";
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_POST, 1L);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, post_fields.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_callback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
    struct curl_slist* headers = 0;
    headers = curl_slist_append(headers, "Content-Type: application/x-www-form-urlencoded");
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    CURLcode res = curl_easy_perform(curl);
    auto http_code = 0;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_code);
    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
    if (res != CURLE_OK || http_code != 200) return "";
    return response;
}

std::string curl_get(std::string url, std::string header, int* http_code_out) {
    std::string response = "";
    CURL* curl = curl_easy_init();
    if (!curl) return "";
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_callback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
    struct curl_slist* headers = 0;
    headers = curl_slist_append(headers, header.c_str());
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    CURLcode res = curl_easy_perform(curl);
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, http_code_out);
    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
    if (res != CURLE_OK) return "";
    return response;
}

std::string curl_put(std::string url, std::string post_fields, std::string header, int* http_code_out) {
    std::string response = "";
    CURL* curl = curl_easy_init();
    if (!curl) { *http_code_out = 0; return ""; }
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "PUT");
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, post_fields.c_str());
    curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, post_fields.size());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_callback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
    struct curl_slist* headers = 0;
    headers = curl_slist_append(headers, header.c_str());
    headers = curl_slist_append(headers, "Content-Type: application/x-www-form-urlencoded");
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    CURLcode res = curl_easy_perform(curl);
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, http_code_out);
    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
    if (res != CURLE_OK) { *http_code_out = 0; return ""; }
    if (*http_code_out == 204) return "";
    return response;
}

std::string c_spotify::generate_random_string(const int len) {
    static const std::string c = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        "abcdefghijklmnopqrstuvwxyz"
        "0123456789";
    thread_local static std::random_device rd;
    thread_local static std::mt19937 g(rd());
    thread_local static std::uniform_int_distribution<size_t> d(0, c.length() - 1);
    auto res = std::string(len, '\0');
    std::generate_n(begin(res), len, [&]() { return c[d(g)]; });
    return res;
}

std::string c_spotify::generate_code_verifier() {
    return generate_random_string(64);
}

std::string c_spotify::generate_code_challenge(const std::string& code_verifier) {
    std::vector<unsigned char> hash(picosha2::k_digest_size);
    picosha2::hash256(code_verifier.begin(), code_verifier.end(), hash.begin(), hash.end());
    return cppcodec::base64_url_unpadded::encode(hash);
}

/*
bool c_spotify::get_token() {
    if (auth_code.code.empty()) return false;
    CURL* curl = curl_easy_init();
    if (!curl) return false;
    std::string response;
    std::string post_fields = "grant_type=authorization_code"
        "&code=" + auth_code.code +
        "&redirect_uri=" + redirect_uri +
        "&client_id=" + client_id +
        "&code_verifier=" + code_verifier;
    curl_easy_setopt(curl, CURLOPT_URL, "https://accounts.spotify.com/api/token");
    curl_easy_setopt(curl, CURLOPT_POST, 1L);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, post_fields.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_callback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
    struct curl_slist* headers = 0;
    headers = curl_slist_append(headers, "Content-Type: application/x-www-form-urlencoded");
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    CURLcode res = curl_easy_perform(curl);
    auto http_code = 0;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_code);
    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
    if (res != CURLE_OK || http_code != 200) return false;
    json j = json::parse(response);
    if (j.contains("access_token")) {
        current_token.access_token = j["access_token"].get<std::string>();
        current_token.refresh_token = j.contains("refresh_token") ? j["refresh_token"].get<std::string>() : "";
        current_token.scope = j.contains("scope") ? j["scope"].get<std::string>() : "";
        current_token.expires_in = j.contains("expires_in") ? j["expires_in"].get<int>() : 0;
        return true;
    }
    return false;
}
*/

bool c_spotify::get_token() {
    if (auth_code.code.empty()) return false;
    CURL* curl = curl_easy_init();
    if (!curl) return false;
    std::string url = "https://accounts.spotify.com/api/token";
    std::string post_fields = "grant_type=authorization_code"
        "&code=" + auth_code.code +
        "&redirect_uri=" + redirect_uri +
        "&client_id=" + client_id +
        "&code_verifier=" + code_verifier;
    std::string response = curl_post(url, post_fields);
    json j = json::parse(response);
    if (j.contains("access_token")) {
        current_token.access_token = j["access_token"].get<std::string>();
        current_token.refresh_token = j.contains("refresh_token") ? j["refresh_token"].get<std::string>() : "";
        current_token.scope = j.contains("scope") ? j["scope"].get<std::string>() : "";
        current_token.expires_in = j.contains("expires_in") ? j["expires_in"].get<int>() : 0;
        return true;
    }
    return false;
}

bool c_spotify::authorize() {
    code_verifier = generate_code_verifier();
    auto code_challenge = generate_code_challenge(code_verifier);
    std::string state = generate_random_string(16);
    auto url_escape = [](CURL* curl, const std::string& input) -> std::string {
        if (input.empty()) return "";
        auto escaped = curl_easy_escape(curl, input.c_str(), (int)(input.length()));
        if (!escaped) return "";
        std::string result(escaped);
        curl_free(escaped);
        return result;
    };
    CURL* handle = curl_easy_init();
    if (!handle) return false;
    std::string auth_url = "https://accounts.spotify.com/authorize"
        "?response_type=code"
        "&client_id=" + client_id +
        "&redirect_uri=" + url_escape(handle, redirect_uri) +
        "&state=" + state.c_str() +
        "&scope=" + url_escape(handle, scope) +
        "&code_challenge_method=S256" +
        "&code_challenge=" + code_challenge;
    curl_easy_cleanup(handle);
    httplib::Server server;
    server.Get("/lilith/spotify", [&](const httplib::Request& req, httplib::Response& res) {
        if (req.has_param("code") && req.get_param_value("state") == state) {
            auth_code.code = req.get_param_value("code");
            auth_code.state = req.get_param_value("state");
            res.set_content("<html><body><h1>authorization successful!</h1><p>you can close this window.</p></body></html>", "text/html");
        }
        else if (req.has_param("error")) {
            auth_code.error = req.get_param_value("error");
            res.set_content("<html><body><h1>authorization declined!</h1><p>please try again.</p></body></html>", "text/html");
        }
        else {
            res.set_content("<html><body><h1>authorization failed!</h1><p>please try again.</p></body></html>", "text/html");
        }
        server.stop();
    });
    std::thread listener_thread([&]() {
        server.listen("127.0.0.1", 6969);
    });
    ShellExecute(0, "open", auth_url.c_str(), 0, 0, 1);
    if (listener_thread.joinable()) listener_thread.join();
    if (auth_code.code.empty()) return false;
    return get_token();
}

bool c_spotify::refresh_token() {
    if (current_token.refresh_token.empty()) return false;
	CURL* curl = curl_easy_init();
    if (!curl) return false;
	std::string url = "https://accounts.spotify.com/api/token";
    std::string post_fields = "grant_type=refresh_token"
        "&refresh_token=" + current_token.refresh_token +
        "&client_id=" + client_id;
    std::string response = curl_post(url, post_fields);
	json j = json::parse(response);
    if (j.contains("access_token")) {
        current_token.access_token = j["access_token"].get<std::string>();
        current_token.refresh_token = j.contains("refresh_token") ? j["refresh_token"].get<std::string>() : current_token.refresh_token;
        current_token.scope = j.contains("scope") ? j["scope"].get<std::string>() : "";
        current_token.expires_in = j.contains("expires_in") ? j["expires_in"].get<int>() : 0;
        return true;
    }
	return false;
}

bool c_spotify::get_current_playback(now_playing& playback) {
    if (current_token.access_token.empty()) return false;
    std::string url = "https://api.spotify.com/v1/me/player/currently-playing";
    std::string header = "Authorization: Bearer " + current_token.access_token;
    int http_code;
	std::string response = curl_get(url, header, &http_code);
    if (http_code == 204) { printf("playback fetch code 204.\n"); playback = now_playing{}; return true; }
    if (http_code == 401) { printf("token expired.\n"); return false; }
    if (http_code != 200) { printf("error code - %d\n", http_code); playback = now_playing{}; return false; }
    json j = json::parse(response);
    if (j.contains("item")) {
        playback.song_name = j["item"].contains("name") ? j["item"]["name"].get<std::string>() : "";
        if (j["item"].contains("artists") && j["item"]["artists"].is_array() && !j["item"]["artists"].empty()) {
            std::string temp;
            auto count = 0;
            for (const auto& artist : j["item"]["artists"]) {
                if (artist.contains("name") && artist["name"].is_string() && !artist["name"].empty()) {
                    if (count > 0) temp += ", ";
                    temp += artist["name"].get<std::string>();
                    count++;
                }
            }
			playback.artist_name = temp;
        }
        else {
            playback.artist_name = "";
        }
        if (j["item"].contains("album") && j["item"]["album"].contains("images") && j["item"]["album"]["images"].is_array() && !j["item"]["album"]["images"].empty()) {
            playback.art_url = j["item"]["album"]["images"][0].contains("url") ? j["item"]["album"]["images"][0]["url"].get<std::string>() : "";
        }
        else {
            playback.art_url = "";
        }
        playback.is_playing = j.contains("is_playing") ? j["is_playing"].get<bool>() : false;
        playback.duration_ms = j["item"].contains("duration_ms") ? j["item"]["duration_ms"].get<int>() : 0;
        playback.progress_ms = j.contains("progress_ms") ? j["progress_ms"].get<int>() : 0;
		playback.track_id = j["item"].contains("id") ? j["item"]["id"].get<std::string>() : "";
		playback.song_url = j["item"].contains("external_urls") && j["item"]["external_urls"].contains("spotify") ? j["item"]["external_urls"]["spotify"].get<std::string>() : "";
        return true;
    }
	return false;
}

bool c_spotify::seek_position(int position_ms) {
    if (current_token.access_token.empty()) return false;
    std::string url = "https://api.spotify.com/v1/me/player/seek";
	std::string post_fields = "position_ms=" + std::to_string(position_ms);
    std::string header = "Authorization: Bearer " + current_token.access_token;
    int http_code = 0;
    std::string response = curl_put(url, post_fields, header, &http_code);
    if (response.empty() && http_code == 204) return true;
    if (http_code == 0) return false;
    if (response.empty()) return false;
    //printf(response.data());printf("%s\n", j["error"]["message"].get<std::string>().c_str());
	json j = json::parse(response);
    if (j.contains("error")) printf("%s\n", j["error"]["message"].get<std::string>().c_str());
	return !j.contains("error");
}

bool c_spotify::set_is_playing(bool play) {
    if (current_token.access_token.empty()) return false;
    std::string url = play ? "https://api.spotify.com/v1/me/player/play" : "https://api.spotify.com/v1/me/player/pause";
    std::string post_fields = "";
    std::string header = "Authorization: Bearer " + current_token.access_token;
    int http_code = 0;
    std::string response = curl_put(url, post_fields, header, &http_code);
    if (response.empty() && http_code == 204) return true;
    if (http_code == 0) return false;
    if (response.empty()) return false;
    json j = json::parse(response);
    if (j.contains("error")) printf("%s\n", j["error"]["message"].get<std::string>().c_str());
    return !j.contains("error");
}

void print_playback_data(const now_playing& playback) {
    int duration_sec = playback.duration_ms / 1000;
    int progress_sec = playback.progress_ms / 1000;
    int duration_min = duration_sec / 60;
    duration_sec %= 60;
    int progress_min = progress_sec / 60;
    progress_sec %= 60;

    std::cout << "status   - "<< (playback.is_playing ? "playing" : "paused") << "\n";
    if (!playback.song_name.empty()) {
        std::cout << "song     - " << playback.song_name << "\n";
        std::cout << "artist   - " << playback.artist_name << "\n";
        std::cout << "progress - " << 
            std::setfill('0') << std::setw(2) << progress_min << ":" <<
            std::setfill('0') << std::setw(2) << progress_sec << " / " <<
            std::setfill('0') << std::setw(2) << duration_min << ":" <<
            std::setfill('0') << std::setw(2) << duration_sec << "\n";
        std::cout << "track id - " << playback.track_id << "\n";
        std::cout << "song url - " << playback.song_url << "\n";
        std::cout << "art url  - " << playback.art_url << "\n";
    }
}

bool c_spotify::init() {
    if (!authorize()) {
        printf("spotify authorization failed.\n");
        return false;
	}
    printf("spotify authorized successfully.\n");
    get_current_playback(current_playback);
    print_playback_data(current_playback);
    std::cin.get();
	seek_position(60000);
	return true;
}