#pragma once
#include "curl/curl.h"
#include "nlohmann/json.hpp"
#include "picosha2/picosha2.h"
#include "cppcodec/base64_url_unpadded.hpp"

#include "misc/globals.h"

static size_t write_callback(void* contents, size_t size, size_t nmemb, void* userp) {
	size_t realsize = size * nmemb;
	((std::string*)userp)->append((char*)contents, realsize);
	return realsize;
}

struct auth_response {
	std::string code;
	std::string error;
	std::string state;
};

struct token_data {
	std::string access_token;
	std::string refresh_token;
	std::string scope;
	int expires_in;
};

struct now_playing {
	std::string song_name;
	std::string artist_name;
	std::string song_url;
	std::string art_url;
	std::string track_id;
	bool is_playing;
	int duration_ms;
	int progress_ms;
};

class c_spotify {
public:
	std::string client_id = "047b913490934041af60e17aab3988f6";
	std::string redirect_uri = "http://127.0.0.1:6969/lilith/spotify";
	std::string scope = "user-read-playback-state user-modify-playback-state user-read-currently-playing";
	std::string code_verifier;
	auth_response auth_code;
	token_data current_token;
	now_playing current_playback;
	std::string generate_random_string(const int length);
	std::string generate_code_verifier();
	std::string generate_code_challenge(const std::string& code_verifier);
	bool get_token();
	bool refresh_token();
	bool authorize();
	bool get_current_playback(now_playing& playback);
	bool seek_position(int position_ms);
	bool set_is_playing(bool play);
	bool init();
};

inline c_spotify spotify;